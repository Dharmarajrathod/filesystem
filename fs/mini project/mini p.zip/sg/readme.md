Clone the project and open index.html to run.
